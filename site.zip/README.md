# Sitio personal – Efraín Castañeda Delgado

Sitio estático para GitHub Pages (HTML, CSS y JS, sin dependencias de compilación).

## Estructura

```
/
├── index.html           Inicio
├── experiencia.html     Trayectoria laboral
├── formacion.html       Certificaciones, cursos y grados
├── herramientas.html    Herramientas y conocimientos
├── proyectos.html       Framework de pruebas y canal de YouTube
├── contacto.html        Contacto y descarga del CV
├── css/style.css        Estilos compartidos
├── js/main.js           Scripts (año del pie de página)
├── assets/
│   ├── docs/            CV en PDF
│   └── img/             Imágenes (foto, etc.)
└── .nojekyll            Evita el procesamiento Jekyll de GitHub Pages
```

## Publicar

1. Sube el contenido a un repositorio (por ejemplo `dmefrain02.github.io`).
2. En Settings → Pages, elige la rama `main` y la carpeta `/ (root)`.
